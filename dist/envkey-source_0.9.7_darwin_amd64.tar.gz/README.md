# envkey-source
Set OS-level shell environment variables with EnvKey. Pairs well with Docker.
